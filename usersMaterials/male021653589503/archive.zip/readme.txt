Model by Reallusion iClone from Google 3d Warehouse:

https://3dwarehouse.sketchup.com/user.html?id=0122725873552223594220183
